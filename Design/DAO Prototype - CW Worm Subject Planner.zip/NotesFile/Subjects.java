import java.io.*;

public class Subjects{
	
	public void viewSubject(){
	
		try{
			File chfile= new File("Subjects.txt");
			
			if(chfile.exists()==false){
				//chfile.createNewFile();
				System.out.println("Subject List not created");
			}
			else{	
				BufferedReader br= new BufferedReader(new FileReader(chfile));
				String line;
		
				while((line = br.readLine()) != null){
					System.out.println(line);
				}
			 }
			
		}
		catch(IOException ioe){
		}
	}

	public void addSubject(){
		
	}
	
	public String deleteSubject(){
	
		return "0";
	}

}