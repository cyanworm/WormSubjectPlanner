import java.io.*;
import java.util.Scanner;

public class SaveNotes {
		static Scanner sc= new Scanner(System.in);
		static File file= new File("Notes.txt");
		static PrintWriter output;
	
	
		public static void main(String[] args){
			
			int choose;
			System.out.println("Choose one\n");
			System.out.println("(1) Create Note\n(2) Find Note");
			choose= sc.nextInt();
			
			if(choose==1){ //Create notes
				CreateNotes();
			}
			else if(choose==2){
				OpenNotes();
			}
		}
		
		public static void CreateNotes(){
			System.out.println("Enter filename: ");
			String fname= sc.next();
			File ffile= new File(fname);
			
		
			try{
				ffile.createNewFile();
				
				String os= System.getProperty("os.name").toLowerCase();
				if(os.contains("win")){
					Runtime.getRuntime().exec(new String[] {"rund1132", "url.dll,FileProtocolandler", file.getAbsolutePath()});
				}
				else if(os.contains("mac")){
					Runtime.getRuntime().exec(new String[]{"/usr/bin/open",ffile.getAbsolutePath()});
				}
				else{
					//Runtime.getRuntime().exec(new String[]{"/usr/bin/open",ffile.getAbsolutePath()});
					System.out.println("Seriously?!");
				}
			}
			catch(IOException ioe){
				System.out.println("EEEEEEEXCEption");
			}
			
		}
		
		public static void OpenNotes(){
		
			// Present lists of files
			System.out.println("Enter filename: ");
			String fname= sc.next();
			File ffile= new File(fname);
			
			try{
				String os= System.getProperty("os.name").toLowerCase();
				if(os.contains("win")){
					Runtime.getRuntime().exec(new String[] {"rund1132", "url.dll,FileProtocolandler", file.getAbsolutePath()});
				}
				else if(os.contains("mac")){
					Runtime.getRuntime().exec(new String[]{"/usr/bin/open",ffile.getAbsolutePath()});
				}
				else{
					//Runtime.getRuntime().exec(new String[]{"/usr/bin/open",ffile.getAbsolutePath()});
					System.out.println("Seriously?!");
				}
			}
			catch(IOException ioe){
				System.out.println("EEEEEEEXCEption");
			}
		}


}