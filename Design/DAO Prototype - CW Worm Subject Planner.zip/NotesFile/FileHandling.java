import java.util.Scanner;

public class FileHandling{

	public static void main(String[] args){
		Scanner sc= new Scanner(System.in);
		
		System.out.println("WORM Subject Planner :: NOTES");
		
		Subjects ss= new Subjects();
		Notes nn= new Notes();
		
		ss.viewSubject();	//Prints the lists of all subjects
		
		String fn; //first n :)
		String sn; //second n =)
		String sub;
		
		System.out.println("(1) Choose Subject");
		System.out.println("(2) Exit");
		fn= sc.nextLine();
		
		while(fn.equals("2")==false){		//While the user wants to choose subjects...
			System.out.println("Subject: ");
			sub= sc.nextLine();
			
			nn.viewNotes(sub);
			System.out.println("(1) Create Notes");
			System.out.println("(2) Open Notes");
			System.out.println("(3) Back");
			sn= sc.nextLine();
			
			while(sn.equals("3")==false){
				if(sn.equals("1")){
					
					nn.createNotes(sub);	
				}
				else{
					
					nn.viewNotes(sub);
					nn.openNotes(sub);
				}
				
				nn.viewNotes(sub);
				System.out.println("(1) Create Notes");
				System.out.println("(2) Open Notes");
				System.out.println("(3) Back");
				sn= sc.nextLine();
			}			
			
			ss.viewSubject();
			System.out.println("(1) Choose Subject: ");
			System.out.println("(2) Exit");
			fn= sc.nextLine();
		}
	}

}