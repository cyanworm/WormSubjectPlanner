import java.util.Date;
import java.io.*;
import java.util.Scanner;

public class Notes{
	String subject;
	String title;
	String creationDate;
	String content;
	
	Scanner sc= new Scanner(System.in);
	
	public void viewNotes(String crt){
		
		try{
			File chfile= new File(crt + ".txt");
			
			if(chfile.exists()==false){
				//chfile.createNewFile();
				System.out.println("Subject not created");
			}
			else{
				BufferedReader br= new BufferedReader(new FileReader(chfile));
				String line;
			
				while((line = br.readLine()) != null){
					System.out.println(line);			
				}
			}
		}
		catch(IOException ioe){
		}
		
	}
	
	public void createNotes(String crt){	//crt is the subject
		String title, sub;
		System.out.println("Enter Title: ");
		title= sc.nextLine();
		
		try{	
			File crfile= new File(title + ".txt");
			crfile.createNewFile();
			BufferedWriter bw= new BufferedWriter(new FileWriter(crfile, true));

			bw.write(title + "\n");
			System.out.println("Content: ");
			sub= sc.nextLine();
			bw.write(sub);
			bw.close();
			
			File cr2file= new File(crt + ".txt");
			BufferedWriter bw2= new BufferedWriter(new FileWriter(cr2file, true));
			bw2.write("\n" + title);
			bw2.close();			
		}
		catch(IOException ioe){
		}
	}
	
	public void openNotes(String crt){		//crt is the subject
		String sub;
		System.out.println("Title: ");
		sub= sc.nextLine();
		
		try{	
			File chfile= new File(sub + ".txt");
			
			if(chfile.exists()==false){
				System.out.println("Sabihin mo ng maayos!!!");
			}
			else{
				BufferedReader br= new BufferedReader(new FileReader(chfile));

				String line;
				while((line = br.readLine()) != null){
					System.out.println(line);			
				}
			}
		}
		catch(IOException ioe){
		}
	
	}
	
	public void editNotes(){
	
		
	}
	
	public String deleteNotes(){
		
		return "0";
	}


}